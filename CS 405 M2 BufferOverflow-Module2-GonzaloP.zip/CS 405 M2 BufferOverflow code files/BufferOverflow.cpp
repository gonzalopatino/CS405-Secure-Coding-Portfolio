// BufferOverflow.cpp : Program entry point.
// Author: Gonzalo Patino
//
// Goal: keep main minimal, prevent overflow, validate digits, convert safely.
// Rule: account_number must remain directly before user_input in main.

#include <iostream>
#include <limits>   // std::numeric_limits
#include <cstring>  // std::strlen
#include <cctype>   // std::isdigit
#include <string>   // std::string, std::stoll

// Prints a short banner, only to keep main readable.
static void print_banner() {
    std::cout << "Buffer Overflow Example\n";
    std::cout << "Type a number (or 'q' to quit):\n";
}

// Reads one line into buf with capacity cap.
// Sets was_truncated true if input exceeded cap - 1 characters.
// Guarantees null termination of buf on return.
static bool read_bounded_line(char* buf, std::size_t cap, bool& was_truncated) {
    if (cap == 0) return false;
    was_truncated = false;

    std::cin.getline(buf, static_cast<std::streamsize>(cap));

    if (std::cin.fail() && !std::cin.eof()) {
        was_truncated = true;                // user typed more than cap - 1 chars
        std::cin.clear();                    // clear failbit
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // drop remainder
    }
    return true;
}

// Returns true only if every char in buf is a decimal digit.
// Empty string is considered invalid for this assignment.
static bool digits_only(const char* buf) {
    std::size_t len = std::strlen(buf);
    if (len == 0) return false;
    for (std::size_t i = 0; i < len; ++i) {
        unsigned char ch = static_cast<unsigned char>(buf[i]);
        if (!std::isdigit(ch)) return false;
    }
    return true;
}

// Safely converts buf to long long. Returns true on success.
static bool parse_long_long(const char* buf, long long& out_value) {
    try {
        out_value = std::stoll(std::string(buf));
        return true;
    }
    catch (...) {
        return false;
    }
}

// Orchestrates read, validate, convert, and reporting.
// Keeps all logic out of main. Always prints the account number
// to demonstrate it was not corrupted by input.
static void process_and_report(const std::string& account_number, char* user_input, std::size_t cap) {
    bool was_truncated = false;

    if (!read_bounded_line(user_input, cap, was_truncated)) {
        std::cout << "[Error] Failed to read input.\n";
        std::cout << "Account Number = " << account_number << "\n";
        return;
    }

    // Allow user to exit with 'q' or 'Q'
    if ((std::strlen(user_input) == 1) && (user_input[0] == 'q' || user_input[0] == 'Q')) {
        std::cout << "Exiting program...\n";
        std::exit(0);
    }

    if (was_truncated) {
        std::cout << "[Warning] Input too long. Only the first "
            << (cap - 1) << " characters were accepted.\n";
    }

    if (!digits_only(user_input)) {
        std::cout << "[Error] Please enter digits only.\n";
        std::cout << "Account Number = " << account_number << "\n";
        return;
    }

    long long numeric_value = 0;
    if (!parse_long_long(user_input, numeric_value)) {
        std::cout << "[Error] Number is out of range for 64-bit signed integer.\n";
        std::cout << "Account Number = " << account_number << "\n";
        return;
    }

    std::cout << "You entered: " << numeric_value << "\n";
    std::cout << "Account Number = " << account_number << "\n";
}

int main() {
    print_banner();

    // Required order per assignment: account_number must be directly before the input buffer.
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    while (true) {
        std::cout << "\nEnter a value: ";
        process_and_report(account_number, user_input, sizeof(user_input));
    }
}
